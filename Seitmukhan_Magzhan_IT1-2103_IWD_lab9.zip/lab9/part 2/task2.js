function formValidation() {
  var uid = document.registration.userid;
  var passid = document.registration.passid;
  var uname = document.registration.username;
  var uemail = document.registration.email;
  var umGender = document.registration.mGender;
  var ufGender = document.registration.fGender;
  if (userid_validation(uid, 5, 12)) {
    if (userid_validation(passid, 7, 12)) {
      if (allLetter(uname)) {
        if (ValidateEmail(uemail)) {
          if (validGender(umGender, ufGender)) {
          }
        }
      }
    }
  }
  return false;
}
function userid_validation(uid, mx, my) {
  var uid_len = uid.value.length;
  if (uid_len == 0 || uid_len >= my || uid_len < mx) {
    alert("It should not be empty / length be between " + mx + " to " + my);
    uid.focus();
    return false;
  }
  return true;
}
function allLetter(uname) {
  var letters = /^[A-Za-z]+$/;
  if (uname.value.match(letters)) {
    return true;
  } else {
    alert("Please input alphabet characters only");
    uname.focus();
    return false;
  }
}
function alphanumeric(uadd) {
  var letters = /^[0-9a-zA-Z]+$/;
  if (uadd.value.match(letters)) {
    return true;
  } else {
    alert("Please input alphanumeric characters only");
    uadd.focus();
    return false;
  }
}
function countryselect(ucountry) {
  if (ucountry.value == "Default") {
    alert("Select your country from the list");
    ucountry.focus();
    return false;
  } else {
    return true;
  }
}
function allnumeric(uzip) {
  var numbers = /^[0-9]+$/;
  if (uzip.value.match(numbers)) {
    return true;
  } else {
    alert("Please input numeric characters only");
    uzip.focus();
    return false;
  }
}
function ValidateEmail(uemail) {
  var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
  if (uemail.value.match(mailformat)) {
    return true;
  } else {
    alert("You have entered an invalid email address!");
    uemail.focus();
    return false;
  }
}
function validGender(umGender, ufGender) {
  x = 0;

  if (umGender.checked) {
    x++;
  }
  if (ufGender.checked) {
    x++;
  }
  if (x == 0) {
    alert("Select Male/Female");
    umGender.focus();
    return false;
  } else {
    return true;
  }
}
// // function RegistrationPage(){
// //   var result = true;
// //   var a = document.forms.RegistrationPage.email.value;
// //   var b = document.forms.RegistrationPage.username.value;
// //   var c = document.forms.RegistrationPage.password.value;
// //   var d = document.forms.RegistrationPage.repassword.value;

// //   // write code to declare variables for password and re-password (confirmed password)

// //   // expression for the correct entering email address, username and password validations
// //   var email_v = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
// //   var username_v = /^[a-zA-Z0-9_-]+$/;
// //   var password_v = /^(\S*)?\d+(\S*)?$/;

// //   // define email_message, username_message, password_message and repassword_message
// //   document.getElementById("email_message").innerHTML ="";
// //   document.getElementById("username_message").innerHTML ="";
// //   document.getElementById("password_message").innerHTML ="";
// //   document.getElementById("repassword_message").innerHTML ="";

// //   // if email is left empty/email format is wrong, error message displays information in red color
// //   if (a ==null  a ==""  email_v.test(a) == false){
// //   document.getElementById("email_message").innerHTML = "Email address empty or wrong format";
// //   result = false;
// //   }

// //   // write code here for username validation

// //   if (b==null  b==""  username_v.test(b) == false){
// //   document.getElementById("username_message").innerHTML = "Please enter the correct information";
// //   result = false;
// //   }

// //   if (c==null  c==""  password_v.test(c) == false) {
// //    document.getElementById("password_message").innerHTML = "Please choose the correct password"
// //    result = false
// //   }

// //   if (d==null  d==""  password_v.test(d) == false || d !== c) {
// //    document.getElementById("repassword_message").innerHTML = "Re-password and Password are different"
// //    result = false
// //   }

// //   if(result == true) {
// //    document.getElementById("display").innerHTML= "Email: " +a+ "<br>" +"Username: " + b + "<br>" +"Password: " + c + "br"
// //    document.getElementById("RegistrationPage").reset()
// //    }
// //   }
// //   function ResetForm(){
// //   }

// function RegistrationPage() {
//   var result = true;
//   var a = document.forms.RegistrationPage.email.value;
//   var b = document.forms.RegistrationPage.username.value;
//   var c = document.forms.RegistrationPage.password.value;
//   var d = document.forms.RegistrationPage.repassword.value;
//   // write code to declare variables for password and re-password (confirmed password)

//   // expression for the correct entering email address, username and password validations
//   var email_v = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
//   var username_v = /^[a-zA-Z0-9_-]+$/;
//   var password_v = /^(\s*)?\d+(\s*)?$/;
//   // define email_message, username_message, password_message and repassword_message
//   document.getElementById("email_message").innerHTML = "";
//   document.getElementById("username_message").innerHTML = "";
//   document.getElementById("password_message").innerHTML = "";
//   document.getElementById("repassword_message").innerHTML = "";
//   // if email is left empty/email format is wrong, error message displays information in red color if (a==null || a =="" || email_v.test(a) == false) { document.getElementById("email_message").innerHTML="Email address empty or wrong format"; }
//   // if (a ==null  a ==""  email_v.test(a) == false){
//   //   document.getElementById("email_message").innerHTML = "Email address empty or wrong format";
//   //   result = false;
//   //   }
//   // write code here for username validation
//   if ((b = null || b == "" || username_v.test(b) == false)) {
//     document.getElementById("username_message").innerHTML =
//       "Please enter the correct information";
//     result = false;
//   }
//   //write code here for password validation form
//   //write code here for confirm password validation form
//   //Information about User is displayed on the bottom if correct information is entered.
//   if (result == true) {
//     document.getElementById("display").innerHTML =
//       "Email: " +
//       a +
//       "<br>" +
//       "Username: " +
//       b +
//       "<br>" +
//       "Password: " +
//       c +
//       "<br>";
//   }
//   +"Confirm Password: " + d + "<br>";
//   document.getElementById("RegistrationPage").reset();
// }
// function ResetForm() {}
