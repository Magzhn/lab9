$(function () {
  $("#draggable").draggable();
});
function draggable() {
  var element = document.getElementById("draggablep");
  element.classList.add("draggableeee");
}
$(function () {
  $("#selectable").selectable();
});
$(function () {
  $("#accordion").accordion();
});
$(function () {
  $("#tabs").tabs();
});
