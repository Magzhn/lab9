// const list = document.querySelector('ul');
// const input = document.querySelector('input');
// const button = document.querySelector('button');

// button.onclick = function() {
//  let myItem = input.value;
//  input.value = '';

//  const listItem = document.createElement('li');
//  const listText = document.createElement('span');
//  const listBtn = document.createElement('button');
//  const editInput = document.createElement('input')
//  const okBtn = document.createElement('button')
//  var recBtn = document.createElement('button')

//  listItem.appendChild(listText);
//  listText.textContent = myItem;
//  listItem.appendChild(listBtn);
//  listBtn.textContent = 'Delete';
//  listItem.appendChild(recBtn)
//  recBtn.textContent = 'Edit'
//  list.appendChild(listItem);

//  listBtn.onclick = function(e) {
//   list.removeChild(listItem);
//  }
//  input.focus();

//  recBtn.onclick = function(e) {
//   listItem.appendChild(listText);
//   listText.textContent = myItem;
//   listItem.appendChild(listBtn);
//   listBtn.textContent = 'Delete';
//   listItem.appendChild(recBtn)
//   recBtn.textContent = 'Edit'
//   list.appendChild(listItem);
//   listItem.appendChild(editInput)
//   listItem.appendChild(okBtn)
//   okBtn.textContent = 'Ok'
//  }

//  okBtn.onclick = function(e) {

//    let newItem = editInput.value;
//    editInput.value = '';

//    listItem.appendChild(listText);
//    listText.textContent = newItem;
//    listItem.appendChild(listBtn);
//    listBtn.textContent = 'Delete';
//    listItem.appendChild(recBtn)
//    recBtn.textContent = 'Edit'
//    list.appendChild(listItem);
//    listItem.removeChild(editInput)
//    listItem.removeChild(okBtn)
//  }
// }

var wishForm = document.querySelector("#wishFormId");
var addInput = document.querySelector("#addInputId");
var addButton = document.querySelector("#addButtonId");
var clearButton = document.querySelector("#clearButtonId");
var wishList = document.querySelector("#wishListId");
var container = document.querySelector("#container");

// Save data while refreshing
wishForm.addEventListener("submit", function (e) {
  e.preventDefault();
});

// Add wish
addButton.addEventListener("click", function () {
  var wish = document.createElement("input");
  wish.type = "text";
  wish.setAttribute("readonly", "readonly");
  wish.setAttribute("class", "wishInput");
  wish.classList.add("wish");
  wish.value = addInput.value;
  wishList.appendChild(wish);

  // Edit wish
  var editButton = document.createElement("button");
  editButton.textContent = "Edit";
  wishList.appendChild(editButton);
  editButton.setAttribute("class", "editButton");

  editButton.addEventListener("click", function () {
    if (editButton.innerText == "Edit") {
      wish.removeAttribute("readonly");
      wish.focus();
      editButton.innerText = "Save";
    } else {
      wish.setAttribute("readonly", "readonly");
      editButton.innerText = "Edit";
    }
  });
  // Delete wish
  var delButton = document.createElement("button");
  var delimg = document.createElement("img");
  delimg.src = "images/cross.png";
  wishList.appendChild(delButton);
  delButton.appendChild(delimg);
  delButton.addEventListener("click", function () {
    wishList.removeChild(delButton);
  });
  delButton.addEventListener("click", function () {
    wishList.removeChild(wish);
  });
  delButton.addEventListener("click", function () {
    wishList.removeChild(editButton);
  });
  delButton.addEventListener("click", function () {
    wishList.removeChild(doneButton);
  });
  delButton.addEventListener("click", function () {
    wishList.removeChild(favButton);
  });
  delButton.setAttribute("class", "delButton");

  // Null the value of Input
  addInput.value = "";

  // Already done wishes style
  var doneButton = document.createElement("button");
  var doneimg = document.createElement("img");
  doneimg.src = "images/done.png";
  doneButton.appendChild(doneimg);
  wishList.appendChild(doneButton);
  doneButton.setAttribute("class", "doneButton");
  doneButton.addEventListener("click", function () {
    wish.style.textDecoration = "line-through";
  });
  // Favourite button
  var favButton = document.createElement("button");
  var favimg = document.createElement("img");
  favimg.setAttribute("src", "images/bookmark.png");
  favButton.appendChild(favimg);
  wishList.appendChild(favButton);
  favButton.setAttribute("class", "favButton");

  favButton.addEventListener("click", function () {
    if (favButton.favimg.src == "images/bookmark.png") {
      favimg.setAttribute("src", "images/bookmark2.png");
      // favimg.src = "images/bookmark2.png";
    } else {
      // favimg.src = "images/bookmark.png";
      favimg.setAttribute("src", "images/bookmark.png");
    }
  });
});
clearButton.addEventListener("click", function () {
  container.removeChild(wishList);
});
